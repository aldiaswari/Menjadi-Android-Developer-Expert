package com.cuplix.cupita.core.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}